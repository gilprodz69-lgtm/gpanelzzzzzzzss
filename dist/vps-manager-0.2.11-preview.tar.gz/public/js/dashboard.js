import{esc,number,badge,api}from'./api.js';
import{icon}from'./icons.js';
export const empty=(title,body='',glyph='servers')=>`<div class="empty">${icon(glyph)}<strong>${esc(title)}</strong>${body?`<p>${esc(body)}</p>`:''}</div>`;
const head=(title,href)=>`<div class="panel-heading"><h2>${title}</h2>${href?`<a class="button small subtle" href="#/${href}">Ver todos</a>`:''}</div>`;
const gauge=(label,value,color,caption)=>{const percent=value===null?null:Math.max(0,Math.min(100,Number(value)));return`<div class="gauge ${color}"><h3>${label}</h3><div class="gauge-wrap"><svg viewBox="0 0 110 110"><circle cx="55" cy="55" r="43"/><circle class="value" cx="55" cy="55" r="43" stroke-dasharray="${percent===null?0:percent*2.70177} 270.177"/></svg><strong>${percent===null?'—':percent.toLocaleString('pt-BR',{maximumFractionDigits:1})+'%'}</strong></div><p>${caption}</p></div>`;};
function chart(rows){
 const width=760,height=125,left=38,top=9,bottom=109;
 const end=Date.now()/1000,start=end-86400,x=t=>left+Math.max(0,Math.min(1,(t-start)/(end-start)))*(width-left-5);
 let grid=[0,25,50,75,100].map(v=>{const y=bottom-v/100*(bottom-top);return`<line class="chart-grid" x1="${left}" y1="${y}" x2="${width-5}" y2="${y}"/><text x="0" y="${y+4}">${v}%</text>`;}).join('');
 for(let i=0;i<7;i++){const t=start+i*(end-start)/6,px=x(t);grid+=`<line class="chart-grid" x1="${px}" y1="${top}" x2="${px}" y2="${bottom}"/><text x="${px}" y="${height}" text-anchor="${i===0?'start':i===6?'end':'middle'}">${new Date(t*1000).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}</text>`;}
 let lines='';
 for(const[key,color]of[['cpu','#1678ff'],['ram','#9432ff'],['disk','#ff9c11']]){
  let group=[],previous=null;const groups=[];
  for(const row of rows){if(previous!==null&&row.created_at-previous>1200){groups.push(group);group=[];}group.push(row);previous=+row.created_at;}if(group.length)groups.push(group);
  for(const segment of groups){const coords=segment.map(r=>`${x(r.created_at)},${bottom-Math.max(0,Math.min(100,+r[key]))/100*(bottom-top)}`);lines+=`<polyline points="${coords.join(' ')}" fill="none" stroke="${color}" stroke-width="1.8"/>`;const last=segment.at(-1);lines+=`<circle cx="${x(last.created_at)}" cy="${bottom-Math.max(0,Math.min(100,+last[key]))/100*(bottom-top)}" r="2.5" fill="${color}"/>`;}
 }
 return`<svg viewBox="0 0 ${width} ${height}" role="img" aria-label="Histórico real de utilização das últimas 24 horas">${grid}${lines}</svg>${rows.length===0?'<div class="chart-empty"><strong>Aguardando métricas do agente</strong><span>O histórico aparecerá após as primeiras coletas.</span></div>':''}`;
}
const bytes=n=>n==null?'—':n>=1073741824?(n/1073741824).toFixed(1)+' GB':n>=1048576?(n/1048576).toFixed(1)+' MB':n>=1024?(n/1024).toFixed(1)+' KB':Math.round(n)+' B';
export async function renderDashboard(ctx){
 const d=await api('/dashboard');let users=[],history=[];
 const tasks=[];
 if(ctx.can('users.view'))tasks.push(api('/users').then(r=>users=r.data));
 if(d.servers.length&&ctx.can('metrics.view'))tasks.push(api(`/servers/${d.servers[0].id}/metrics?hours=24`).then(r=>history=r.data));
 await Promise.all(tasks);
 const live=d.servers.filter(s=>s.status==='online'&&s.metrics);
 const sum=key=>live.reduce((n,s)=>n+Number(s.metrics[key]||0),0);
 const total=sum('disk_total'),used=sum('disk_used'),storage=document.querySelector('.storage-widget');
 if(storage){storage.querySelector('.storage-label').innerHTML=`<span>${total?bytes(used)+' de '+bytes(total):'Aguardando coleta'}</span><span>${total?(used/total*100).toFixed(1)+'%':'—'}</span>`;storage.querySelector('.track span').dataset.width=total?used/total*100:0;}
 const collected=live.length?Math.min(...live.map(s=>Number(s.metrics.created_at))):null;
 const network=live.some(s=>s.metrics.network_rx_bps!=null)?`<div class="gauge orange"><h3>Rede</h3><div class="gauge-wrap"><strong>${bytes(sum('network_rx_bps'))}/s</strong></div><p>↓ Recebidos · ↑ ${bytes(sum('network_tx_bps'))}/s</p></div>`:gauge('Rede',null,'orange','Aguardando duas coletas');
 const mean=key=>live.length?live.reduce((sum,s)=>sum+Number(s.metrics[key]),0)/live.length:null;
 const cards=[['Servidores VPS',d.servers.length,'Total de servidores','servers',''],['Usuários',d.counts.users,'Clientes e usuários','users',''],['Revendedores',users.filter(u=>u.role==='RESELLER').length,'Revendedores ativos','resellers','purple'],['Sites',d.counts.websites??0,'Sites hospedados','websites',''],['Bancos de Dados',d.counts.databases??0,'Bancos criados','databases',''],['SSL / Certificados',d.counts.ssl_certificates??0,'Certificados registrados','ssl_certificates','green']];
 const now=new Date();const dt=now.toLocaleDateString('pt-BR',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
 const serverRows=d.servers.slice(0,3).map(s=>`<div class="server-row"><i class="dot ${s.status==='online'?'':s.status==='offline'?'offline':'unknown'}"></i><span class="server-symbol">${icon('servers')}</span><div class="server-name"><strong>${esc(s.name)}</strong><small>${esc(s.address)}</small></div>${badge(s.status)}<div class="server-detail">CPU ${s.metrics?Math.round(s.metrics.cpu)+'%':'—'} | RAM ${s.metrics?Math.round(s.metrics.ram)+'%':'—'}<br>${esc(s.os)}</div></div>`).join('');
 return`<div class="dashboard-page"><section class="greeting"><span class="wave" aria-hidden="true">👋</span><div class="greeting-copy"><h1>Olá, ${esc(ctx.me.user.name.split(' ')[0])}!</h1><p>Aqui está um resumo geral do seu ambiente VPS Manager.</p></div><div class="greeting-date">${esc(dt[0].toUpperCase()+dt.slice(1))}<time>${now.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}</time><span class="connection"><i class="dot"></i>Painel online</span></div>${ctx.can('servers.create')?`<button class="button primary" data-create="servers">${icon('plus')}Adicionar Servidor</button>`:''}</section>
 <section class="stats-grid" aria-label="Resumo do ambiente">${cards.map(([label,count,caption,glyph,color])=>`<article class="stat-card"><div class="stat-icon ${color}">${icon(glyph)}</div><div class="stat-info"><h2>${label}</h2><div class="stat-number"><strong>${number(count)}</strong></div><p>${caption}</p></div></article>`).join('')}</section>
 <div class="dashboard-grid"><section class="panel resources-panel">${head('Uso dos Recursos')}<p class="status-note">${collected?'Última coleta: '+new Date(collected*1000).toLocaleTimeString('pt-BR')+' · Atualização a cada 10 s':'Sem coleta recente. Verifique o serviço de métricas.'}</p><div class="gauges">${gauge('CPU',mean('cpu'),'','Média dos servidores online')}${gauge('Memória RAM',mean('ram'),'purple',sum('memory_total')?bytes(sum('memory_used'))+' de '+bytes(sum('memory_total')):'Aguardando coleta')}${gauge('Armazenamento',mean('disk'),'green',total?bytes(used)+' de '+bytes(total):'Aguardando coleta')}${network}</div></section>
 <section class="panel overview-panel">${head('Visão Geral dos Servidores','servers')}<div class="server-list">${serverRows||empty('Nenhum servidor conectado','Adicione sua primeira VPS para acompanhar CPU, memória e disponibilidade.','servers')}</div></section>
 <section class="panel chart-panel"><div class="panel-heading"><h2>Consumo de Recursos <span>(Últimas 24 horas)</span></h2><div class="legend"><span><i></i>CPU</span><span><i class="ram"></i>RAM</span><span><i class="disk"></i>Disco</span></div></div><div class="chart-wrap">${chart(history)}</div></section>
 </div>
 ${d.pending_jobs?`<p class="status-note">${icon('jobs')} ${number(d.pending_jobs)} operação(ões) aguardando processamento. <a href="#/jobs">Acompanhar fila</a></p>`:''}</div>`;
}
