<!doctype html>
<html lang="pt-BR" data-theme="light">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="theme-color" content="#0b1321">
  <title>VPS Manager</title>
  <link rel="icon" href="/images/logo.svg" type="image/svg+xml">
  <link rel="stylesheet" href="/css/app.css">
  <link rel="stylesheet" href="/css/file-manager.css">
  <script src="/js/app.js" type="module"></script>
</head>
<body>
  <div id="app"><div class="boot"><img src="/images/logo.svg" width="48" height="48" alt=""><span>VPS Manager</span><p>Carregando seu ambiente…</p></div></div>
  <div id="toast" role="status" aria-live="polite"></div>
  <dialog id="modal" aria-labelledby="modal-title"></dialog>
</body>
</html>
